import { useState } from 'react'

const API_BASE = 'http://localhost:8080';

export default function App() {
  const [url, setUrl] = useState('');
  const [shortUrl, setShortUrl] = useState('');
  const [history, setHistory] = useState([]);
  const [error, setError] = useState('');

  const randomCode = () => {
    const chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    return Array.from({length: 6}, () => chars[Math.floor(Math.random() * chars.length)]).join('');
  };

  const shortenUrl = async () => {
    setError('');
    if (!url) return setError('Enter URL');
    if (!url.startsWith('http')) return setError('Must start with http/https');

    try {
      const res = await fetch(`${API_BASE}/shorten`, {
        method: 'POST',
        headers: { 'Content-Type': 'text/plain' },
        body: url
      });

      if (!res.ok) throw new Error();

      const data = await res.text();
      setShortUrl(data);
      setHistory([{ shortUrl: data, originalUrl: url }, ...history.slice(0,7)]);
      setUrl('');
    } catch {
      const fake = `${API_BASE}/${randomCode()}`;
      setShortUrl(fake);
      setHistory([{ shortUrl: fake, originalUrl: url }, ...history.slice(0,7)]);
      setError('Demo mode');
    }
  };

  return (
    <div className="container">
      <h1>snip.ly</h1>

      <div className="card">
        <input value={url} onChange={e=>setUrl(e.target.value)} placeholder="Paste URL" />
        <button onClick={shortenUrl}>Shorten</button>
        {error && <p className="error">{error}</p>}
      </div>

      {shortUrl && (
        <div className="card">
          <p>{shortUrl}</p>
        </div>
      )}

      {history.length>0 && (
        <div className="card">
          {history.map((h,i)=>(
            <div key={i}>
              <p>{h.shortUrl}</p>
              <small>{h.originalUrl}</small>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
